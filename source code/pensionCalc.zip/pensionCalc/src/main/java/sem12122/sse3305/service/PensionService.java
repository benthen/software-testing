package sem12122.sse3305.service;

import java.util.ArrayList;

public interface PensionService {
	ArrayList<String> kirapencen(ArrayList<String> details);

}
